export interface Alert {
  title: string;
  content: string;
}
