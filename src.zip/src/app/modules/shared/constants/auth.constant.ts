export const AUTHKEY = {
  ADMIN: 'MHSADM',
  USER: 'MHSUSR',
  SUPER: 'Y',
  CLAIMUSER:'mhslift.com'
};
