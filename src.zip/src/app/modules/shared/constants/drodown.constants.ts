export const WOSTATUS_DATA = [
  { key: 0, value: 'Normal Work Order' },
  { key: 1, value: 'PM Work Order' },
  { key: 2, value: 'Both' }
];
