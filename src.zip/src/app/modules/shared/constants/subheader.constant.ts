export const AvailableUrls = [
  '/dashboard',
  '/dashboard/pm-request',
  '/dashboard/service-request',
  '/equipments',
  '/work-orders',
  '/preventive-maintenance',
  '/invoices',

];
