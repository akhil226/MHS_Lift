export const  SORT_KEY = {
  equipmentLsiting: 'med.CURRENT_HOUR_METER * 1 desc',
  workListSorting: 'two.UPDATED_ON desc',
  pmListSorting: 'DtPMDue desc',
  invoiceListSorting: 'InvDt desc',
  cutomerListSorting: 'user_fname asc',
  topAssetTotalsSorting: 'amountTotal desc'
};


