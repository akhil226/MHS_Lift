export const MENU_KEY = {
  dashboard: 'DAS',
  notification: 'NOS',
  keyFeatures: 'KEY',
  reqFeatures: 'REQ',
};

