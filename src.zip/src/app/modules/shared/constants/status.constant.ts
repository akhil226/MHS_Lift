export const STATUS = {
  active: 'A',
  inActive: 'I'
}
