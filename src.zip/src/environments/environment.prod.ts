export const environment = {
  production: true,
  baseUrl: 'https://portal-stg.mhslift.com/MHSCPLServices/',
//  baseUrl: 'https://myfleet.mhslift.com/MHSCPLServices/',
  version:"1.2",
  uiVersion:"1.2"
  // woPdfBaseUrl: 'https://portal.mhslift.com/'
}
